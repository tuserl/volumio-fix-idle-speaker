nohup /home/volumio/mysh/play_silent.sh > /home/volumio/mysh/nohup.out 2>&1 &
