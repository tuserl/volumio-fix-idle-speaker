ps aux | grep play_silent.sh
