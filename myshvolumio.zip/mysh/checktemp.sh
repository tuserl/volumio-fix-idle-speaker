sudo vcgencmd measure_temp
